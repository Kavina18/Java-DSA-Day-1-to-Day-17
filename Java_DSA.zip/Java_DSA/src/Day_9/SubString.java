package Day_9;

import java.util.*;

public class SubString {
    public static void subArray(String s,int i,String str){
        if(i==s.length()){
            System.out.println(str);
            return;
        }
        subArray(s,i+1,str+s.charAt(i));
        subArray(s,i+1,str); 
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner (System.in);
        System.out.println("Enter a string:");
        String s=scn.next();
        subArray(s,0,"");
        scn.close();
    }
}
