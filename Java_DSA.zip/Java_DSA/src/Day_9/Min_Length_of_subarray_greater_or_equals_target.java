package Day_9;

import java.util.*;
public class Min_Length_of_subarray_greater_or_equals_target {
    public static int MinLength(int[] arr,int target){
        int count=0,sum=0,min=Integer.MAX_VALUE;
        for(int i=0;i<arr.length;i++){
            count=0;
            for(int j=i;j<arr.length;j++){
                sum+=arr[i];
                count++;
                if(sum>=target){
                   min=Math.min(min,count);
                   sum=0;
                   break;
                }
            }
        }
        return min;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the target:");
        int target=scn.nextInt();
        int res=MinLength(arr,target);
        System.out.println("Minimum length:"+res);
    }
}
