package Day_9;

import java.util.*;
public class Safe_position {
    public static int safe_position(int n,int k){
        if(n==1)
        return 0;
        return (safe_position(n-1,k)+k)%n;
    }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter n:");
        int n=scn.nextInt();
        System.out.println("Enter the k:");
        int k=scn.nextInt();
        int res=safe_position(n,k)+1;
        System.out.println("Safe position:"+res);
    }
}
