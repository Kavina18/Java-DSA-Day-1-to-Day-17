package Day_9;

import java.util.*;
public class Multiplication {
    public static int multiply(int a,int b,int sum,int sign){
        if(b<0){
            sign=1;
            sum+=a;
            return multiply(a, b+1, sum,sign);
        }
        if(b>0){
            sign=0;
            sum+=a;
            return multiply(a, b-1, sum,sign);
        }
        if(sign==1)
        return -1*sum;
        return sum;
    }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter the num1:");
        int a=scn.nextInt();
        System.out.println("Enter the num2:");
        int b=scn.nextInt();
        int res=multiply(a,b,0,0);
        System.out.println(a+" * "+b+" = "+res);
    }
}
