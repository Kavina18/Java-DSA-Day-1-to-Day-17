package Day_9;

import java.util.*;
public class Longest_Con_Increasing_Subsequence {
    public static int longseq(int[] arr,int i,int count,int Max){
        if(arr.length==0)
        return 0;
        if(i<arr.length-1){
            if(arr[i]<arr[i+1])
                count+=1;
                else{
                    count+=1;
                    Max=Math.max(Max,count);
                    count=0;
                }
                return longseq(arr,i+1,count,Max);
            }
            count+=1;
            Max=Math.max(count,Max);
            return Max;
        }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int res=longseq(arr,0,0,Integer.MIN_VALUE);
        System.out.println("Longest Continuous increasing subarray:"+res);
    }
}
