package Day_17;

public class QueueImplementation {
    private int[] queue;
    int front;
    int rear;
    int capacity;
    int size;

    public QueueImplementation(int capacity){
        this.capacity=capacity;
        queue=new int[capacity];
        front=0;
        rear=-1;
        size=0;
    }

    public boolean isFull(){
        if(size>=capacity)
        return true;
        else 
        return false;
    }

    public boolean isEmpty(){
        if(size==0)
        return true;
        else
        return false;
    }


    public void enqueue(int data){
        if(isFull()){
            System.out.println("Queue is Full,can't insert an element...");
        }
        else{
        rear=(rear+1)%capacity;
        queue[rear]=data;
        size++;
    }
    }

    public int dequeue(){
        int element=-1;
        if(isEmpty()){
            System.out.println("Queue is Empty,can't dequeue");
        }
        else{
            element=queue[front];
            front=(front+1)%capacity;
            size--;
        }
        return element;
    }

    public int peek(){
        if(isEmpty())
        return -1;
        else
        return queue[front];
    }

    public int size(){
        return size;
    }
    public void display(){
        System.out.print("QUEUE : ");
        for(int i=front;i<=rear;i++){
            System.out.print(queue[i]+" ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        QueueImplementation queue=new QueueImplementation(10);

        System.out.println("IS EMPTY : "+queue.isEmpty());
        
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        queue.display();

        System.out.println("PEEK : "+queue.peek());

        System.out.println(queue.dequeue());

        queue.display();

        System.out.println("PEEK : "+queue.peek());

        queue.enqueue(6);
        queue.enqueue(7);
        queue.display();

        System.out.println("SIZE : "+queue.size());

        System.out.println("IS FULL : "+queue.isFull());
        System.out.println("IS EMPTY : "+queue.isEmpty());
    }
}
