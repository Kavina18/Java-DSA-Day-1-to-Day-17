package Day_17;

public class QueueUsingLinkedList {

    public class Node{
        int data;
        Node next;
        public Node(int data){
            this.data=data;
            this.next=null;
        }
    }

    Node front,rear;
    int size;
    public QueueUsingLinkedList(){
        this.front=null;
        this.rear=null;
        size=0;
    }

    public void enqueue(int data){
        Node newNode=new Node(data);
        if(size==0){
            front=rear=newNode;
        }
        else{
            rear.next=newNode;
            rear=newNode;
        }
        size++;
    }

    public int dequeue(){
        int element=-1;
        if(size==0){
            System.out.println("Queue is empty,can't delete the element...");
        }
        else{
            element=front.data;
            front=front.next;
            size--;
        }
        return element;
    }

    public int size(){
        return size;
    }

    public boolean isEmpty(){
        if(size==0)
        return true;
        else
        return false;
    }

    public void display(){
        Node temp=front;
        System.out.print("QUEUE : ");
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        QueueUsingLinkedList queue=new QueueUsingLinkedList();

        System.out.println("is empty : "+queue.isEmpty());

        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        queue.display();

        System.out.println("Size : "+queue.size());

        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        queue.display();

        System.out.println("is empty : "+queue.isEmpty());
        System.out.println("Size : "+queue.size());

        queue.enqueue(90);
        queue.display();
        System.out.println("Size : "+queue.size());

    }
}
