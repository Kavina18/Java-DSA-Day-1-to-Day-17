package Day_17;

import java.util.Queue;

import Day_11.perfect_square;

import java.util.ArrayDeque;
import java.util.LinkedList;

import java.util.PriorityQueue;
public class Queue_example {
    public static void main(String[] args) {
        Queue<String> q=new LinkedList<>();
        /*Queue<String> q1=new PriorityQueue<>();
        Queue<String> q2=new ArrayDeque<>();*/
        
        //ADDING AN ELEMENT
        q.offer("Banana");
        q.offer("Apple");
        q.offer("Grapes");
        //q.add("Guava");

        //PEEK ELEMENT(FRONT ELEMENT)
        System.out.println(q.peek());

        //SIZE OF QUEUE
        System.out.println("SIZE : "+q.size());

        //REMOVING AN ELEMENT
        //System.out.println(q.remove());
        System.out.println(q.poll());
        System.out.println(q.poll());
        System.out.println(q.peek());
        System.out.println("SIZE : "+q.size());

        q.offer("Orange");
        q.offer("Strawberry");

        System.out.println(q.poll());
        System.out.println(q.poll());
        System.out.println(q.poll());

        System.out.println("SIZE : "+q.size());

        //is EMPTY
        System.out.println("IS EMPTY : "+q.isEmpty());

        System.out.println(q.poll());
    

    }
}
