package Day_11;

import java.util.*;
public class Sum_of_Xor_of_all_Subarray {
    public static int sum_of_XOR_0f_All_subarray(int[] arr){
        int res_Xor=0;;
        for(int i=0;i<arr.length;i++){
            int xor=0;
            for(int j=i;j<arr.length;j++){
                xor^=arr[j];
                res_Xor^=xor;
            }   
        }
        return res_Xor;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int xor=sum_of_XOR_0f_All_subarray(arr);
        System.out.println("Total Xor:"+xor);
        scn.close();
    }
}
