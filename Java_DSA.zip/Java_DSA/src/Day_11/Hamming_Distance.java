package Day_11;

import java.util.*;
public class Hamming_Distance {
    public static int hamming_Distance(int a,int b){
        int  xor=a^b;
        int count=0;
        while(xor>0){
            int res=(xor%10) & 1 ;
            xor=xor>>1;
            if(res==1)
            {
              count++;
            }
        }
        /*String str=Integer.toBinaryString(xor);
        for(int i=0;i<str.length();i++){
            if(str.charAt(i)=='1'){
                count++;
            }
        }*/
        return count;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter a:");
        int a=scn.nextInt();
        System.out.println("Enter b:");
        int b=scn.nextInt();
        int distance=hamming_Distance(a,b);
        System.out.println("Hamming Distance:"+distance);
    }
}
