package Day_11;

import java.util.*;
public class Binary_search {
    public static int binarySearch(int[] arr,int target){
        int left=0;
        int right=arr.length-1;
        while(left<right){
            int mid=(left+right)/2;
            if(target==arr[mid])
            return mid;
            else if(target<arr[mid]){
                right=mid;
            }
            else{
                left=mid+1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the target:");
        int target=scn.nextInt();
        int res=binarySearch(arr,target);
        System.out.println("index:"+res);
    }
}
