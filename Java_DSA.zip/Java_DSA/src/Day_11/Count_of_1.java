package Day_11;

import java.util.*;
public class Count_of_1 {
    public static int count(int[] arr){
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        int left=0;
        int count=0;
        int right=arr.length-1;
        if(arr[left]==1)
        return arr.length;
        while(left<=right){
            int mid=(left+right)/2;
            if(arr[mid]==0)
            left=mid+1;
            else{
                count=arr.length-mid;
                right=mid-1;
            }
        }
        /*if(arr[arr.length-1]==1)
        count+=1;*/
        return count;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int count=count(arr);
        System.out.println("Count of 1 in the given array is "+count);
    }
}
