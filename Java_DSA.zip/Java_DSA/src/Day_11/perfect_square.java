package Day_11;

import java.util.*;
public class perfect_square {
    public static boolean PerfectSquare(int n){

        /*for(int i=1;i<=Math.sqrt(n);i++){
            if(Math.pow(i, 2)==n)
            return true;
        }
        return false;*/
        /*int val=(int)Math.sqrt(n);
        if(val*val==n)
        return true;
        else
        return false;*/
        if(n==1)
        return true;
        int left=1;
        int right=n;
        while(left<right){
            int mid=(left+right)/2;
            if(mid*mid==n)
            return true;
            else if(n<mid*mid)
            right=mid;
            else
            left=mid+1;
        }
        return false;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        boolean res=PerfectSquare(n);
        if(res==true)
        System.out.println("Is perfect square:YES");
        else
        System.out.println("Is Perfect square:NO");
    }
}
