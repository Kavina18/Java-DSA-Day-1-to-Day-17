package Day_7;

import java.util.*;

public class Boat {
    public static int boats(int[] arr,int limit){
        int count=0;
        int sum=0,left=0,right=arr.length-1;
        Arrays.sort(arr);
        while(left<right){
            sum=arr[left]+arr[right];
            /*if(sum>limit){
                count++;
                right--;
            }
            else{//no less than
                count++;
                left++;
                right--;
            }*/
            if(sum==limit)
                left++;
            right--;
            count++;
        }
        if(sum>limit)
        count++;
        return count;
    }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int size=scn.nextInt();
        int[] arr=new int[size];
        System.out.println("Enter the Array Elements:");
        for(int i=0;i<size;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the limit:");
        int limit=scn.nextInt();
        int count=boats(arr,limit);
        System.out.println("Number of boats required: "+count);
    }
}
