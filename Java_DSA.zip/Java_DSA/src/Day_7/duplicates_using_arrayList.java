package Day_7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class duplicates_using_arrayList {
    public static ArrayList<Integer> duplicate(int[] arr){
        //Arrays.sort(arr);
        ArrayList<Integer> duplicate=new ArrayList<Integer>();
        /*for(int i=0;i<arr.length-1;i++){
            if(arr[i]==arr[i+1] && !duplicate.contains(arr[i])){
                duplicate.add(arr[i]);
            }
        }*/
        for(int i=0;i<arr.length;i++){
            int index=Math.abs(arr[i])-1;
            if(arr[index]<0){
                duplicate.add(index+1);
            }
            arr[index]=-arr[index];
        }
        return duplicate;
      }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int size=scn.nextInt();
        int[] arr=new int[size];
        System.out.println("Enter the Array Elements:");
        for(int i=0;i<size;i++){
            arr[i]=scn.nextInt();
        }
        ArrayList<Integer> result=duplicate(arr);
        System.out.println("Duplicates:"+result);
    }
}
