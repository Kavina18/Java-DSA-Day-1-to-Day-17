package Day_7;
import java.util.*;

public class Count_of_Subarrays_Product_lessthan_k {
    public static int Count(int[] arr,int k){
        /*int count=0;
        for(int i=0;i<arr.length;i++){ 
            int product=1;
            for(int j=i;j<arr.length;j++){
                product*=arr[j];
                if(product<k){
                    count++;
                }
                else{
                    break;
                }
            }
        }*/

        //2 pointer approach
        int count=0;
        int right=0,left=0,product=1;
        if(k<=1)
        return 0;
        for(right=0;right<arr.length;right++){
            product*=arr[right];
            while(product>=k){
                product/=arr[left];
                left++;
            }
            count+=right-left+1;
        }
        return count;
    }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int size=scn.nextInt();
        int[] arr=new int[size];
        System.out.println("Enter the Array Elements:");
        for(int i=0;i<size;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the product value:");
        int k=scn.nextInt();
        int count=Count(arr,k);
        System.out.println("Number of subarray whose product is Less than "+k+" : "+count);
    }
}
