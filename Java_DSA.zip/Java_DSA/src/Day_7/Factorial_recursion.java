package Day_7;

import java.util.*;
public class Factorial_recursion {
    public static int factorial(int n){
        if(n==0 || n==1)
        return 1;
        return n*factorial(n-1);
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        int Factorial=factorial(n);
        System.out.println("Factorial of "+n+" is "+Factorial);
    }
}
