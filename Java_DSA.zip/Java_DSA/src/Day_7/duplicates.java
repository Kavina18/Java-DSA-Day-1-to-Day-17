package Day_7;

import java.util.*;

public class duplicates {
    public static void duplicate(int[] arr){
        int[] duplicate=new int[arr.length];
        Arrays.sort(arr);
        int k=0;
        System.out.println("Duplicates:");
        for(int i=0;i<arr.length-1;i++){
            if(k==0 &&arr[i]==arr[i+1]){
                duplicate[k]=arr[i];
                System.out.print(duplicate[k]+" ");
                k++;
            }
            else if(arr[i]==arr[i+1] && duplicate[k-1]!=arr[i]){
                duplicate[k]=arr[i];
                System.out.print(duplicate[k]+" ");
                k++;
            }
        }
      }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int size=scn.nextInt();
        int[] arr=new int[size];
        System.out.println("Enter the Array Elements:");
        for(int i=0;i<size;i++){
            arr[i]=scn.nextInt();
        }
        duplicate(arr);
        
    }
}
