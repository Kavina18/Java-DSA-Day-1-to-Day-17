package Day_7;

import java.util.Scanner;

public class recursion {
    public static void Print_dec(int n){
        if(n>0){
        System.out.println(n);
        Print_dec(n-1);}

    }
    public static void Print_asc(int n){
        if(n>0){
        Print_asc(n-1);
        System.out.println(n);}
    }
    public static void PrintPattern(int n){
        if(n>0){
        System.out.println(n);
        PrintPattern(n-1);
        System.out.println(n);}
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        System.out.println("Descending order:");
        Print_dec(n);
        System.out.println("Ascending order:");
        Print_asc(n);
        System.out.println("Pattern order:");
        PrintPattern(n);
    }
}
