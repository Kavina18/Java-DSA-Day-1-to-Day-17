package Day_13;

public class Implementation_LL {
    public static class singlyLinkedList{
        private static class Node{
            int data;
            Node next;
            Node(int data){
                this.data=data;
                this.next=null;
            }
        }
        private Node head;
        private Node tail;
        private int size;
        public singlyLinkedList(){
            head=null;
            tail=null;
        }
        public void insertAtEnd(int data){
            Node newNode=new Node(data);
            if(head==null){
                head=newNode;
                tail=newNode;
            }
            else{
                tail.next=newNode;
                tail=newNode;
            }
            size++;
        }
        public void insertAtBegin(int data){
            Node newNode=new Node(data);
            if(head==null){
                head=newNode;
                tail=newNode;
            }
            else{
                newNode.next=head;
                head=newNode;
            }
            size++;
        }
        public void insertAtGivenIndex(int index,int data){
            if(index < 0 || index > size){
                throw new IndexOutOfBoundsException("Invalid index");
            }
            if(index==0){
                insertAtBegin(data);
            }
            else if(index==size){
                insertAtEnd(data);
            }
            else{
                Node newNode=new Node(data);
                Node temp=head;
                for(int i=0;i<index-1;i++){
                    temp=temp.next;
                }
                newNode.next=temp.next;
                temp.next=newNode;
            }
        }
        public void display(){
            Node temp=head;
            System.out.print("List : ");
            while(temp!=null){
                System.out.print(temp.data+" ");
                temp=temp.next;
            }
        }
        public void removeAt(int index){
            if(index<0 || index>=size){
                throw new IndexOutOfBoundsException("Invalid Index");
            }
            if(index==0){
                head=head.next;
                if(head==null){
                    tail=null;
                }
            }
            else{
                Node temp=head;
                for(int i=0;i<index-1;i++){
                    temp=temp.next;
                }
                temp.next=temp.next.next;
                if(temp.next==null){
                    tail=temp;
                }
            }
            size--;
        }
    }
    public static void main(String[] args) {
        singlyLinkedList list=new singlyLinkedList();
        list.insertAtEnd(5);
        list.insertAtEnd(10);
        list.insertAtEnd(4);
        list.display();
        System.out.println();
        System.out.println(list.head.data);
        System.out.println(list.head);
        System.out.println(list.head.next);
        System.err.println(list.tail.next);
        list.insertAtBegin(15);
        list.display();
        System.out.println();
        System.out.println(list.head.data);
        list.insertAtGivenIndex(2, 20);
        list.display();
    }
}
