package Day_13;

import java.util.*;

public class LinkedList_ex {
    public static void main(String[] args) {
        LinkedList<String> list=new LinkedList<>();

        //1.Adding elements
        list.add("Apple");
        list.add("Banana");
        list.add("Orange");
        System.out.println("LinkedList : "+list);
        
        //2.Adding at specific index
        list.addFirst("Mango");
        list.addLast("Strawberry");
        list.add(1,"Grapes");
        System.out.println("LinkedList : "+list);

        System.out.println("Size of LinkedList : "+list.size());

        //3.Accessing the LL
        System.out.println(list.getFirst());
        System.out.println(list.getLast());
        System.out.println(list.get(3));

        //4.Removing the elements
        list.removeFirst();
        list.removeLast();
        list.remove(2);
        System.out.println("LinkedList : "+list);

        System.out.println("Size of LinkedList : "+list.size());

        //5.contains
        System.out.println(list.contains("Apple"));
        System.out.println(list.contains("Banana"));

        //6.Updating the list elements
        list.set(1, "Blueberry");
        list.set(0, "Pineapple");
        System.out.println("LinkedList : "+list);

        //7.to clear
        list.clear();
        System.out.println("LinkedList after clearing : "+list);

        //8.isempty
        System.out.println("IS EMPTY"+list.isEmpty());

        //9.size
        System.out.println("Size of LinkedList : "+list.size());

        list.add("Apple");
        list.add("Banana");
        list.add("Orange");

        //10.iteration
        System.out.println("LinkedList : ");
        for(String fruits:list){
            System.out.println(fruits);
        }

        //11.iteration using iterator method
        System.out.println("LinkedList : ");
        Iterator<String> i=list.iterator();
        while(i.hasNext()){
            System.out.println(i.next());
        }
    }
}
