package Day_2;

import java.util.Scanner;

public class RTriangle_Pattern {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter a number:");
        int num=scn.nextInt();
        for (int i=0;i<num;i++){//O(n)
            for(int j=0;j<=i;j++){//O(n)
                System.out.print("*");
            }
            System.out.println();
        } 
        scn.close(); 
    }
}
//Time Complexity=O(N^2)
//SpaceComplexity=O(1)