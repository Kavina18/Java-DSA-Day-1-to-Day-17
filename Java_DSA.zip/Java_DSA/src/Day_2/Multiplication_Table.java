package Day_2;

import java.util.Scanner;

public class Multiplication_Table {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter a Number:");
        int num=scn.nextInt();
        for(int i=1;i<=10;i++){
            System.out.println(num+" * "+i+" = "+num*i);
        }
        scn.close();
    }
}
