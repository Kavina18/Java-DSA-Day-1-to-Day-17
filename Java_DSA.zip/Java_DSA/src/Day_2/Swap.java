package Day_2;

import java.util.Scanner;

public class Swap {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter a number 1:");
        int num1=scn.nextInt();
        System.out.println("Enter a number 2:");
        int num2=scn.nextInt();
        int num3=num1;
        num1=num2;
        num2=num3;
        System.out.println("Number 1:"+num1+"\nNumber 2:"+num2);
        scn.close();
    }
}
