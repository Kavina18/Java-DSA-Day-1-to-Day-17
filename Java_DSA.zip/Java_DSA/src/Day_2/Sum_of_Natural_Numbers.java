package Day_2;
import java.util.*;
public class Sum_of_Natural_Numbers {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter a number:");
        int num=scn.nextInt();
        int sum=0;
        for(int i=1;i<=num;i++){
            sum+=i;
        }
        System.err.println("Sum is "+sum);
        scn.close();
    }
}
