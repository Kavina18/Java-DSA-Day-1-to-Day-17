package Day_2;

import java.util.Scanner;

public class Last_Digit_Even_or_Odd {
    public static void main(String[] args) {
         Scanner scn=new Scanner(System.in);
        System.out.println("Enter a Number:");
        int num=scn.nextInt();
        if((num%10)%2==0){
            System.out.println("Last Digit is Even");
        }
        else{
            System.out.println("Last Digit is Odd");
        }
        scn.close();
    }
}
