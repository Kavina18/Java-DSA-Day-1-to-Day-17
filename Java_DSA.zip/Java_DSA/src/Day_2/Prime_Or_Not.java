package Day_2;

import java.util.Scanner;

public class Prime_Or_Not {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter a number:");
        int num=scn.nextInt();
        int flag=0,i=2;
        for(i=2;i<=Math.sqrt(num);i++)
        //for(i=2;i<num/2;i++)
        {
            if(num%i==0){
                flag=1;
                break;
            }
        }
        if(flag==0)
        System.out.println("Prime");
        else
        System.out.println("Not a Prime Number");
        scn.close();
    }
}
