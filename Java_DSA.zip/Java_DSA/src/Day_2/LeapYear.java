package Day_2;
import java.util.*;
public class LeapYear {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        int year=scn.nextInt();
        /*if(year%4==0 && year%400==0 || year%100!=0){
            System.out.println("Leap Year");
        }
        else{
            System.out.println("Not a Leap Year");
        }*/
        if(year%4==0){
            if(year%100==0){
                if(year%400==0){
                    System.out.println("Leap Year");
                }
                else{
                    System.out.println("Not a Leap Year");
                }
            }
            System.out.println("Leap Year");
        }
        else{
            System.out.println("Not a Leap Year");
        }
        scn.close();
    }
}
