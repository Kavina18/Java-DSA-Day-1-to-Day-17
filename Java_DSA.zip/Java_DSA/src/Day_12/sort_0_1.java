package Day_12;

import java.util.*;

public class sort_0_1 {
    public static int[] sort(int[] arr){
        int left=0;
        int right=arr.length-1;
        while(left<right){
            if(arr[left]==1 && arr[right]==0){
                int temp=arr[left];
                arr[left]=arr[right];
                arr[right]=temp;
                left++;
                right--;
            }
            else if(arr[left]==0)
                left++;
            else
                right--;
        }
        return arr;
    }
    public static void main(String[] args) {
         Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int[] res_arr=sort(arr);
        System.out.println(Arrays.toString(res_arr));
    }
}
