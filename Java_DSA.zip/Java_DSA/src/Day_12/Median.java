package Day_12;

import java.util.*;

public class Median {
    public static double median(int[] arr){
        Arrays.sort(arr);
        double median=arr[0];
        int index=arr.length/2;
        if(arr.length%2==0)
            median=(arr[index]+arr[index-1])/2.0;
        else
            median=arr[index];
        return median;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        double median=median(arr);
        if(arr.length%2==0)
        System.out.println("Median:"+median);
        else
        System.out.println("Median:"+(int)median);
        scn.close();
    }
}
