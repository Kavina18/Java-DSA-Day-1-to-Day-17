package Day_12;

import java.util.Arrays;
import java.util.Scanner;

public class Odd_Even_sort {
    public static int[] sort(int[] arr){
        /*for(int i=0;i<arr.length-1;i++){
            for(int j=i+1;j<arr.length;j++){
                if(arr[i]>arr[j]){
                    int temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        return arr;*/
        boolean isSorted=false;
        while(!isSorted){
            isSorted=true;
            //odd
            for(int j=1;j<arr.length-1;j+=2){
                if(arr[j]>arr[j+1]){
                      int temp=arr[j];
                      arr[j]=arr[j+1];
                      arr[j+1]=temp;  
                      isSorted=false;         
                }
                
            }
            //even
            for(int j=0;j<arr.length-1;j+=2){
                if(arr[j]>arr[j+1]){
                    int temp=arr[j];
                    arr[j]=arr[j+1];  
                    arr[j+1]=temp;   
                    isSorted=false;            
              }
            }  
        }
        return arr;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int[] res=sort(arr);
        System.out.println(Arrays.toString(res));
        scn.close();
    }
}
