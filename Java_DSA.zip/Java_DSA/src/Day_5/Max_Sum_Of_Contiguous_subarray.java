package Day_5;

import java.util.Scanner;

public class Max_Sum_Of_Contiguous_subarray {
    public static int Max_Sum(int[] arr){
        int max=arr[0];
        int current_max=arr[0];
        for(int i=1;i<arr.length;i++){
            current_max=Math.max(arr[i],current_max+arr[i]);
            max=Math.max(max,current_max);
        }
        return max;

    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int Result_sum=Max_Sum(arr);
        System.out.println("Maximum sum of contiguous subarray : "+Result_sum);
        scn.close();
    }
}
