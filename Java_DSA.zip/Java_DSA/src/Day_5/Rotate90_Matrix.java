package Day_5;

import java.util.Scanner;

public class Rotate90_Matrix {
    public static int [][] initializeArray(int rows,int col){
        Scanner scn=new Scanner(System.in);
        int[][] a=new int[rows][col];
        System.out.println("Enter the array Elements:");
        for(int i=0;i<rows;i++){
            for(int j=0;j<col;j++){
                a[i][j]=scn.nextInt();
            }
        }
        return a;
    }
    public static void printArray(int[][] arr){
        System.out.println("ARRAY:");
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void rotate90(int[][] arr,int rows,int col) {
        System.out.println("Rotated array:");
            for(int j=0;j<col;j++){
                for(int i=rows-1;i>=0;i--){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
            }
        /*for(int i=0;i<rows;i++){
            for(int j=0;j<rows;j++){
            int temp=arr[i][j];
            arr[i][j]=arr[j][i];
            arr[j][i]=temp;
            }
        }
        for(int i=0;i<rows;i++){
            for(int j=col-1;j>=0;j++){
                System.out.println(arr[i][j]+" ");
            }
        }*/
    }
    public static void main(String[] args) {
         Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number of rows:");
        int rows=scn.nextInt();
        System.out.println("Enter the number of columns:");
        int col=scn.nextInt();
        int [][] arr=initializeArray(rows,col);
        printArray(arr);
        rotate90(arr,rows,col);
    }
}
