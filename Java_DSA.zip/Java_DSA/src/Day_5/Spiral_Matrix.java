package Day_5;

import java.util.Scanner;

public class Spiral_Matrix {
    public static int [][] initializeArray(int rows,int col){
        Scanner scn=new Scanner(System.in);
        int[][] a=new int[rows][col];
        System.out.println("Enter the array Elements");
        for(int i=0;i<rows;i++){
            for(int j=0;j<col;j++){
                a[i][j]=scn.nextInt();
            }
        }
        return a;
    }
    public static void printArray(int[][] arr){
        System.out.println("ARRAY:");
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void spiral_Matrix(int[][] arr,int rows,int col){
        /*for(int count=0;count<2;count++){
            for(int i=count;i<col-1-count;i++){
                System.out.print(arr[count][i]+" ");
            }
            for(int j=count;j<rows-1-count;j++){
                System.out.print(arr[j][col-1-j]+" ");
            }
            for(int k=col-1-count;k>count;k--){
                System.out.print(arr[rows-1-count][k]+" ");
            }
            for(int l=rows-1-count;l>count;l--){
                System.out.print(arr[l][count]+" ");
            }
        }*/
        int top=0;
        int bottom=rows-1;
        int left=0;
        int right=col-1;
        System.out.println("Spiral matrix : ");
        while(top<=bottom && left<=right){
            //left->right
            for(int i=left;i<=right;i++){
                System.out.print(arr[top][i]+" ");
            }
            top++;
            //top->bottom
            for(int i=top;i<=bottom;i++){
                System.out.print(arr[i][right]+" ");
            }
            right--;
            //right->left
            for(int i=right;i>=left;i--){
                System.out.print(arr[bottom][i]+" ");
            }
            bottom--;
            //bottom->top
            for(int i=bottom;i>=top;i--){
                System.out.print(arr[i][left]+" ");
            }
            left++;
        }

    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number of rows:");
        int rows=scn.nextInt();
        System.out.println("Enter the number of columns:");
        int col=scn.nextInt();
        int [][] arr=initializeArray(rows,col);
        printArray(arr);
        spiral_Matrix(arr,rows,col);
    } 
}
