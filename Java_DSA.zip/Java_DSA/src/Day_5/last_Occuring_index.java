package Day_5;

import java.util.Scanner;

public class last_Occuring_index {
    public static int last_Occuring_Index(int[] arr,int value){
        int index=-1;
        for(int i=0;i<arr.length;i++){
            if(arr[i]==value)
            index=i;
        }
        return index;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the value:");
        int value=scn.nextInt();
        int last_Index=last_Occuring_Index(arr,value);
        System.out.println("Last Occuring index of "+value+" is "+last_Index);
    }
}
