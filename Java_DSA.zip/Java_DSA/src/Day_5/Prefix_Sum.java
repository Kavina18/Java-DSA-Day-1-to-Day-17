package Day_5;

import java.util.Scanner;

public class Prefix_Sum {
    public static int subArray_Sum(int[] arr,int i,int j){
        /*int sum=0;
        for(int k=i;k<=j;k++){
            sum+=arr[k];
        }
            return sum; */
        int[] prefix=new int[arr.length];
        int sum=arr[0];
        prefix[0]=sum;
        for(int k=1;k<arr.length;k++){
            sum+=arr[k];
            prefix[k]=sum;
        }
        int result_Sum=0;
        if(i==0)
        result_Sum=prefix[j];
        else
        result_Sum=prefix[j]-prefix[i-1];
        return result_Sum;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the start index:");
        int i=scn.nextInt();
        System.out.println("Enter the end index:");
        int j=scn.nextInt();
        int Sum_Result=subArray_Sum(arr,i,j);
        System.out.println("Sum between "+i+" and "+j+" : "+Sum_Result);
    }
}
