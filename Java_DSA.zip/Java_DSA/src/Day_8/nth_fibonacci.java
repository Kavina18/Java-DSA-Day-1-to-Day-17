package Day_8;

import java.util.Scanner;

public class nth_fibonacci {
    public static int fibonacci(int n){
        /*
        starts from fibonacci of 1:
        if(n==0 || n==1)
        return 0;
        else if(n==2)
        return 1;
        else
        return fibonacci(n-1)+fibonacci(n-2);*/

        //starts from fibonacci of 0:
        if(n==0)
        return 0;
        else if(n==1)
        return 1;
        else
        return fibonacci(n-1)+fibonacci(n-2);
      }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        int fibo=fibonacci(n);
        System.out.println(n+"th fibonacci number:"+fibo);
    }
}
