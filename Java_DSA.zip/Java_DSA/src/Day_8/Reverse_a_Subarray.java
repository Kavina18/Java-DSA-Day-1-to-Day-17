package Day_8;

import java.util.*;
public class Reverse_a_Subarray {
    public static int[] reverse(int[] arr,int left,int right){
        if(left<right){
        int temp=arr[left];
        arr[left]=arr[right];
        arr[right]=temp;
        return reverse(arr, left+1, right-1);
        }
        else
        return arr;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] array =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            array[i]=scn.nextInt();
        }
        System.out.println("Enter the left index:");
        int left=scn.nextInt();
        System.out.println("Enter the right:");
        int right=scn.nextInt();
        if(left<right){
            int[] result=reverse(array,left,right);
            System.out.println(Arrays.toString(result));
        }
        else{System.out.println("Invalid Indices");
        }

    }
}
