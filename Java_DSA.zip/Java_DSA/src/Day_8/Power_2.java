package Day_8;

import java.util.Scanner;

public class Power_2 {
    public static int power(int n,int p){
        if(p==0)
        return 1;
        int res=power(n,p-1);
        return n*res;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        System.out.println("Enter the power:");
        int p=scn.nextInt();
        int res=power(n,p);
        System.out.println(n+" ^ "+p+" = "+res);
    }
}
