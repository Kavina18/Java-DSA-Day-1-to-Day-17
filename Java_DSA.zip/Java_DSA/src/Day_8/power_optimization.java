package Day_8;

import java.util.Scanner;

public class power_optimization {
    public static int power(int n,int p){
        if(p==0)
        return 1;
        int halfp=power(n,p/2);
        if(p%2==0){
            return halfp*halfp;
        }
        else{
            return n*halfp*halfp;
        }
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        System.out.println("Enter the power:");
        int p=scn.nextInt();
        int res=power(n,p);
        System.out.println(n+" ^ "+p+" = "+res);
    }
}
