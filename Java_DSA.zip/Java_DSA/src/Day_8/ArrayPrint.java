package Day_8;

import java.util.Scanner;

public class ArrayPrint {
    public static void printArray_from_first(int[] arr,int index){
        if(index<arr.length){
            System.out.println(arr[index]);
            printArray_from_first(arr, index+1);
        }
    }
    public static void printArray_from_last(int[] arr,int index){
        if(index>=0){
            System.out.println(arr[index]);
            printArray_from_last(arr,index-1);
        }
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] array =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            array[i]=scn.nextInt();
        }
        System.out.println("Printing from first:");
        printArray_from_first(array,0);
        System.out.println("Printing from last:");
        printArray_from_last(array,array.length-1);
    }
}
