package Day_8;

import java.util.Scanner;

public class maximum_element_using_recursion_1 {
    public static int maximum(int[] arr,int n,int max){
        if(n==0)
        return max;
        max=Math.max(max,arr[n-1]);
        return maximum(arr,n-1,max);
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] array =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            array[i]=scn.nextInt();
        }
        int max=Integer.MIN_VALUE;
        int res_max=maximum(array,n,max);
        System.out.println("Maximum element : "+res_max);
    }
}
