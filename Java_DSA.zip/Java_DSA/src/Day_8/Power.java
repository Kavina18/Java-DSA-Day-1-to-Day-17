package Day_8;

import java.util.Scanner;

public class Power {
    public static int power(int n,int p,int product){
        if(p>0){
            product*=n;
            return power(n, p-1,product);
        }
        return product;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        System.out.println("Enter the power:");
        int p=scn.nextInt();
        int res=power(n,p,1);
        System.out.println(n+" ^ "+p+" = "+res);
    }
}
