package Day_8;

import java.util.Scanner;

public class Print_String {
    public static void printString(String s,int n){
        /*if(n>0){
            printString(s,n-1);
        }
        System.out.println(s.charAt(n));*/
        if(n<s.length()){
            System.out.println(s.charAt(n));
            printString(s, n+1);
        }
    }
    public static void main(String[] args) {
        Scanner scn =new Scanner(System.in);
        System.out.println("Enter the String:");
        String s=scn.next();
        //printString(s,s.length()-1);  //BY LENGTH(REVERSE)
        System.out.println("Printing:");
        printString(s,0);  //BY INDEX(FROM 0 TO LAST)
    }
}
