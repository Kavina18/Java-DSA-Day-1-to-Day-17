package Day_8;

import java.util.Scanner;

public class maximum_element_recursion_2 {
    public static int maximum(int[] arr,int left,int right){
        if(left==right){
            return arr[left];
        }
        int mid=(left+right)/2;
        int leftmax=maximum(arr,left,mid);
        int rightmax=maximum(arr,mid+1,right);
        return Math.max(leftmax,rightmax);
      }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] array =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            array[i]=scn.nextInt();
        }
        int left=0;
        int right=array.length-1;
        int res_max=maximum(array,left,right);
        System.out.println("Maximum element : "+res_max);
    }
}
