package Day_16;

class Node{

     int val;
     Node next;
    public Node(int val){
        this.val=val;
        this.next=null;
    }

}
class Stack{

    private Node head;
    private int size;
     public Stack(){
        this.head=null;
        this.size=0;
     }
     public void push(int val){
        Node newNode=new Node(val);
        newNode.next=head; //insert at begin
        head=newNode;
        size++;
     }

     public void pop(){ // delete at begin
        if(size==0)
        System.out.println("No element to pop");
        else{
        System.out.println("Pop : "+head.val);
        head=head.next;
        size--;
    }
    }

     public int peek(){
        if(size==0)
        return -1;
        return head.val;
     }

     public int size(){
        return size;
     }

     public void display(){
        Node temp=head;
        System.out.println("Stack : ");
        while(temp!=null){
            System.out.print(temp.val+" ");
            temp=temp.next;
        }
        System.out.println();
     }
     public boolean isEmpty(){
        if(size==0)
        return true;
        else
        return false;
     }
}


public class StackUsingLL {
    public static void main(String[] args) {
        Stack st=new Stack();
        System.out.println("isEmpty : "+st.isEmpty());
        st.push(10);
        st.push(20);
        st.push(30);
        st.push(40);
        st.push(50);
        st.push(60);
        st.display();
        System.out.println("Size : "+st.size());
        System.out.println("Peek element : "+st.peek());
        st.pop();
        st.pop();
        st.display();
        System.out.println("Size : "+st.size());
        System.out.println("Peek element : "+st.peek());
        System.out.println("isEmpty : "+st.isEmpty());

    }
}
