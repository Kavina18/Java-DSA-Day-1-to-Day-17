package Day_16;

import java.util.*;
public class StackUsingArray {
    private int[] arr;
    private int maxSize;
    private int index;
    private int size;
    public StackUsingArray(int size){
        this.maxSize=size;
        this.arr=new int[maxSize];
        this.index=0;
        this.size=0;
    }

    public boolean isFull(){
        if(size<maxSize)
            return false;
        else
            return true;
    }

    public boolean isEmpty(){
        if(size==0)
        return  true;
        else
        return false;
    }


    public void push(int data){
        if(isFull()){
            System.out.println("Stack overFlow,can't insert "+data);
        }
        else{
        arr[index]=data;
        index++;
        size++;}
    }


    public void pop(){
        if(isEmpty()){
            System.out.println("Stack underflow,can't pop...");
        }
        else{
        System.out.println("Pop : "+arr[index-1]);
        index-=2;
        size--;}
    }
    public int peek(){
        if(isEmpty())
        return -1;
        return arr[size-1];
    }

    public void display(){
        System.out.println("Stack:");
        for(int i=0;i<size;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
    public int size(){
        return size;
    }
    
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        int size=scn.nextInt();
        StackUsingArray stack=new StackUsingArray(size);
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);
        stack.push(60);
        stack.display();
        stack.pop();
        stack.display();
        System.out.println("Peek element :  "+stack.peek());
        System.out.println("size of Stack :  "+stack.size());
        scn.close();
    }
}
