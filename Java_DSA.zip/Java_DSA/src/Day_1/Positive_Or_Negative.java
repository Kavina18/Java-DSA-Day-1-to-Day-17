package Day_1;
import java.util.Scanner;
public class Positive_Or_Negative {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        int num=scn.nextInt();
        if(num>0){
            System.out.println("Positive");
        }
        else if(num==0){
            System.out.println("Zero");
        }
        else{
            System.out.println("Negative");
        }
        scn.close();
    }
}
