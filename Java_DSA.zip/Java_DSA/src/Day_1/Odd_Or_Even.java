package Day_1;
import java.util.Scanner;
public class Odd_Or_Even {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        int num=scn.nextInt();
        if(num%2==0){
            System.out.println("The Give Number "+num+" is Even");
        }
        else{
            System.out.println("The Give Number "+num+" is Odd");
        }
        scn.close();
    }
}
