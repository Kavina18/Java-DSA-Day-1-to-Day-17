package Day_1;
import java.util.Scanner;
public class Grading_System {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        int mark=scn.nextInt();
        if(mark>=90){
            System.out.println("Grade:A");
        }
        else if(mark>=80 && mark<=89){
            System.out.println("Grade:B");
        }
        else if(mark>=70 && mark<=79){
            System.out.println("Grade:C");
        }
        else if(mark>=60 && mark<=69){
            System.out.println("Grade:D");
        }
        else{
            System.out.println("Grade:F");
        }
        scn.close();
    }
}
