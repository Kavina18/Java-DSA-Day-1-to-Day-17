package Day_1;
import java.util.Scanner;
public class Greatest_Number {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        int num1,num2,num3;
        num1=scn.nextInt();
        num2=scn.nextInt();
        num3=scn.nextInt();
        if(num1>num2 && num1>num3){
            System.out.println(num1+" is Greatest");
        }
        else if(num2>num1 && num2>num3){
            System.out.println(num2+" is Greatest");
        }
        else{
            System.out.println(num3+" is Greatest");
        }
        scn.close();
    }
}
