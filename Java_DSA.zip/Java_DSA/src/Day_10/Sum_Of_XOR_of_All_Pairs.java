package Day_10;

import java.util.*;
public class Sum_Of_XOR_of_All_Pairs {
    public static int sum_of_XOR_Pairs(int[] arr){
        int sum=0;
        for(int i=0;i<arr.length-1;i++){
            for(int j=i+1;j<arr.length;j++){
                sum+=(arr[i]^arr[j]);
            }
        }
        return sum;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int sum=sum_of_XOR_Pairs(arr);
        System.out.println("Sum:"+sum);
    }
}
