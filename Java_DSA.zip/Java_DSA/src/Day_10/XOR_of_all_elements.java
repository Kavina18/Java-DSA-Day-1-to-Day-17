package Day_10;

import java.util.Scanner;

public class XOR_of_all_elements {
    public static int all_XOR(int n){
        /*if(n==0)
        return 0;
        else if(n==1)
        return 1;
        int xor=1;
        for(int i=2;i<=n;i++){
            xor^=i;
        }
        return xor;*/
        if(n%4==1)
        return 1;
        else if(n%4==2)
        return n+1;
        else if(n%4==0)
        return n;
        else
        return 0;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number:");
        int n=scn.nextInt();
        int xor=all_XOR(n);
        System.out.println("Xor:"+xor);
        scn.close();
    }
}
