package Day_10;

public class Binary {
    public static void main(String[] args) {
        int i=3;
        String s=Integer.toBinaryString(i);
        System.out.println(s);
    }
}
