package Day_4;

import java.util.Scanner;

public class wave_Array {
    public static int [][] initializeArray(int rows,int col){
        Scanner scn=new Scanner(System.in);
        int[][] a=new int[rows][col];
        System.out.println("Enter the array Elements");
        for(int i=0;i<rows;i++){
            for(int j=0;j<col;j++){
                a[i][j]=scn.nextInt();
            }
        }
        return a;
    }
    public static void printArray(int[][] arr){
        System.out.println("ARRAY:");
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void wave_Array(int[][] arr){
        System.out.println("Wave matrix:");
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(i%2==0){
                    System.out.print(arr[j][i]+" ");
                }
                else{
                    for(int k=arr.length-1;k>=0;k--)
                    {
                        System.out.print(arr[k][i]+" ");
                    }
                    break;
                }
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number of rows:");
        int rows=scn.nextInt();
        System.out.println("Enter the number of columns:");
        int col=scn.nextInt();
        int [][] arr=initializeArray(rows,col);
        printArray(arr);
        wave_Array(arr);
    }
}
