package Day_4;

import java.util.*;
public class TwoD_Array {
    public static int [][] initializeArray(int rows,int col){
        Scanner scn=new Scanner(System.in);
        int[][] a=new int[rows][col];
        System.out.println("Enter the array Elements");
        for(int i=0;i<rows;i++){
            for(int j=0;j<col;j++){
                a[i][j]=scn.nextInt();
            }
        }
        return a;
    }
    public static void printArray(int[][] arr){
        System.out.println("ARRAY:");
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static int[][] modifyArray(int[][] arr,int ri,int ci,int value){
        if(ri >=0 && ri<arr.length && ci>=0 && ci<arr[0].length)
        arr[ri][ci]=value;
        else
        System.out.println("Invalid Index...");
        return arr;
    }
    public static int sumOfElements(int[][] arr){
        int result_sum=0;
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                result_sum+=arr[i][j];
            }
        }
        return result_sum;
    }
    public static int find_Max(int[][] arr){
        int result_max=arr[0][0];
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]>result_max)
                result_max=arr[i][j];
            }
        }
        return result_max;
    }
    public static int find_Min(int[][] arr){
        int result_min=arr[0][0];
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]<result_min)
                result_min=arr[i][j];
            }
        }
        return result_min;
    }
    public static int[][] traverse_Row(int[][] arr){
        int[][] a=new int[arr.length][arr[0].length];
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                a[i][j]=arr[i][j];
            }
        }
        return a;
    }
    public static int[][] traverse_Col(int [][] arr) {
        int[][] a=new int[arr.length][arr[0].length];
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                a[i][j]=arr[j][i];
            }
        }
        return a;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number of rows:");
        int rows=scn.nextInt();
        System.out.println("Enter the number of columns:");
        int col=scn.nextInt();
        int [][] arr=initializeArray(rows,col);
        printArray(arr);

        //Modify the array
        System.out.println("Enter the row index to modify:");
        int ri=scn.nextInt();
        System.out.println("Enter the column index to modify:");
        int ci=scn.nextInt();
        System.out.println("Enter the value to modify:");
        int value=scn.nextInt();
        int[][] modified_array=modifyArray(arr,ri,ci,value);
        printArray(modified_array);

        //Sum of the Array
        int sum=sumOfElements(arr);
        System.out.println("Total sum of the Array:"+sum);

        //Maximum element in the array
        int Max_Element=find_Max(arr);
        System.out.println("Maximum element in the Array:"+Max_Element);

        //Minimum element in the array
        int Min_Element=find_Min(arr);
        System.out.println("Minimum element in the Array:"+Min_Element);

        //Row wise traverse matrix
        int[][] row_traverse=traverse_Row(arr);
        System.out.println("Matrix in Row traverse:");
        printArray(row_traverse);

        //Column wise traverse matrix
        int[][] col_traverse=traverse_Col(arr);
        System.out.println("Matrix in Column traverse:");
        printArray(col_traverse);
    }
}