package Day_4;

import java.util.Scanner;

public class Matrix_multiplication {
    public static int [][] initializeArray(int rows,int col){
        Scanner scn=new Scanner(System.in);
        int[][] a=new int[rows][col];
        System.out.println("Enter the array Elements");
        for(int i=0;i<rows;i++){
            for(int j=0;j<col;j++){
                a[i][j]=scn.nextInt();
            }
        }
        return a;
    }
    public static void printArray(int[][] arr){
        System.out.println("ARRAY:");
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static int[][] Multiply(int[][] arr1,int arr2[][]){
        int[][] multi=new int[arr1.length][arr2[0].length];
        int sum=0;
        for(int i=0;i<arr1.length;i++){
            for(int j=0;j<arr2[0].length;j++){
                for(int k=0;k<arr1[0].length;k++){
                    sum+=arr1[i][k]*arr2[k][j];
                }
                multi[i][j]=sum;
                sum=0;
            }
        }
        return multi;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the number of rows:");
        int rows1=scn.nextInt();
        System.out.println("Enter the number of columns:");
        int col1=scn.nextInt();
        int [][] arr1=initializeArray(rows1,col1);
        printArray(arr1);
        System.out.println("Enter the number of rows:");
        int rows2=scn.nextInt();
        System.out.println("Enter the number of columns:");
        int col2=scn.nextInt();
        int [][] arr2=initializeArray(rows2,col2);
        printArray(arr2);
        if(arr1[0].length==arr2.length){
            int[][] muptiple_Matrix=Multiply(arr1,arr2);
            printArray(muptiple_Matrix);
        }
        else{
            System.out.println("Invalid dimension");
        }
    }
}
