package Day_3;

import java.util.*;
public class Swap {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int temp=arr[0];
        arr[0]=arr[n-1];
        arr[n-1]=temp;
        for(int i=0;i<n;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
/* Time complexity=O(N)
  Space complexity=O(N)
 */