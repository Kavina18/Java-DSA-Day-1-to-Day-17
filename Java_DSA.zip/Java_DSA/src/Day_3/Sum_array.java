package Day_3;

import java.util.*;

public class Sum_array {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
            System.out.println("Enter the Length:");
            int n=scn.nextInt();
            int[] arr =new int[n];
            System.out.println("Enter the elements of array:");
            for(int i=0;i<n;i++){
              arr[i]=scn.nextInt();
            }
            int sum=0;
            for(int i=0;i<n;i++){
                sum+=arr[i];
            }
            System.out.println("Sum of the given elements in array:"+sum);
        }
}
