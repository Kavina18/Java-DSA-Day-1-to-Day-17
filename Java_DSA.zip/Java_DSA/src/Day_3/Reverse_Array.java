package Day_3;

import java.util.*;
public class Reverse_Array {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        for(int i=0;i<n;i++){//----->O(N)
            arr[i]=scn.nextInt();
        }
        System.out.println("Reversed array:");
        for(int i=0;i<n/2;i++){//---->O(Log N)
            int temp=arr[i];
            arr[i]=arr[(n-1)-i];
            arr[(n-1)-i]=temp;
        }
        for(int i=0;i<n;i++){//---->O(N)
            System.out.print(arr[i]+" ");
        }
    }
}
//Time Complexity=O(N)
//space Complexity=O(N)