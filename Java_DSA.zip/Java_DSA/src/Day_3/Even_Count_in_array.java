package Day_3;
import java.util.*;
public class Even_Count_in_array {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        int even_Count=0;
        for(int i=0;i<n;i++){//----->O(N)
            arr[i]=scn.nextInt();
            if(arr[i]%2==0)
            even_Count++;
        }
     System.out.println("Number of even elements in the given array:"+even_Count);   
    }
}
