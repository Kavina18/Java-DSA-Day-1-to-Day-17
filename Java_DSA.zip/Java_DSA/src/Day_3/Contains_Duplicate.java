package Day_3;

import java.util.*;
public class Contains_Duplicate {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        Arrays.sort(arr);
        int flag=0;
        for(int i=0;i<n-1;i++){
            if (arr[i]==arr[i+1]) {
                flag=1;
                break;
            }
        }
        if(flag==0)
        System.out.println("No duplicates");
        else
        System.out.println("Duplicates found");

    }
}
