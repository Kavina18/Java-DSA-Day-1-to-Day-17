package Day_3;

import java.util.*;
public class Find_Element_in_Array {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the element to Search:");
        int Search_Value=scn.nextInt();
        int flag=0;
        for(int i=0;i<n;i++){
            if(arr[i]==Search_Value){
            System.out.println("location:"+i);
            flag=1;
            }
        }
        if(flag==0)
        System.err.println("Value not found");
    }
}