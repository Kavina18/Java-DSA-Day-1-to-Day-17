package Day_3;
import java.util.*;
public class LargestElement_in_Array {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int max=arr[0];
        for(int i=1;i<n;i++){
            if(arr[i]>max)
            max=arr[i];
        }
        System.out.println("Maximum element is "+max);
    }
}
