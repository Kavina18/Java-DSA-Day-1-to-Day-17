package Day_3;

import java.util.*;
public class Sum_Product_Average {
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Length:");
        int n=scn.nextInt();
        int[] arr =new int[n];
        System.out.println("Enter the elements of array:");
        int sum=0,product=1;
        float avg=0;
        for(int i=0;i<n;i++){//------>O(N)
            arr[i]=scn.nextInt();
            sum+=arr[i];
            product*=arr[i];
        }
        avg=sum/n;
        System.out.println("Sum = "+sum+"\nProduct = "+product+"\nAverage = "+avg);
    }
}
/*Time Complexity=O(N)
Space Complexity=O(N)*/