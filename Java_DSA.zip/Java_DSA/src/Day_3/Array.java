package Day_3;

import java.util.*;
public class Array {
    public static void main(String[] args) {
        int[] arr=new int[5];
        //int[] arr ={1,2,3,4,5};
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the Array Elements:");
        for(int i=0;i<5;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Obtained array:");
        for(int i=0;i<5;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
