package Day_6;

import java.util.Scanner;

public class Pivot_Index {
    public static int pivotIndex(int[] arr){
        /*int index=-1;
        for(int i=0;i<arr.length;i++){
            int lsum=0,rsum=0;
            for(int j=i-1;j>=0;j--){
                lsum+=arr[j];
            }
            for(int k=i+1;k<arr.length;k++){
                rsum+=arr[k];
            }
            if(lsum==rsum){
                index=i;
                break;
            }
        }*/
        int index=-1;
        int totalsum=0,lsum=0;
        for(int i=0;i<arr.length;i++){
            totalsum+=arr[i];
        }
        for(int i=0;i<arr.length;i++){
            int rsum=totalsum-lsum-arr[i];
            if(lsum==rsum){
                index=i;
                break;
            }
            lsum+=arr[i];
        }
        return index;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int Result_index=pivotIndex(arr);
        System.out.println("Pivot index : "+Result_index);
        scn.close();
    }
}
