package Day_6;

import java.util.Arrays;
import java.util.Scanner;

public class Running_sum {
    public static int[] Running_Sum(int[] arr){
        int[] runningsum=new int[arr.length];
        int sum=arr[0];
        runningsum[0]=sum;
        for(int i=1;i<arr.length;i++){
            sum+=arr[i];
            runningsum[i]=sum;
        }
        return runningsum;
    }
    public static void printArray(int[] sum){
        System.out.println("Running sum : ");
        for(int i=0;i<sum.length;i++){
            System.out.print(sum[i]+" ");
        }
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        int[] sum=Running_Sum(arr);
        //printArray(sum);
        System.out.println("Running array : "+Arrays.toString(arr));
    }
}
