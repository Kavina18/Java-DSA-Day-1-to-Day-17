package Day_6;

import java.util.Scanner;

public class Buy_and_Sell {
    public static int Max_Profit(int[] prices){
        int minprice=Integer.MAX_VALUE;
        int maxprofit=0;
        for(int i=0;i<prices.length;i++){
            minprice=Math.min(minprice,prices[i]);
            int profit=prices[i]-minprice;
            maxprofit=Math.max(maxprofit,profit);
        }
        return maxprofit;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] prices=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            prices[i]=scn.nextInt();
        }
        int Max_profit=Max_Profit(prices);
        System.out.println("Maximum Profit:"+Max_profit);
    }
}
