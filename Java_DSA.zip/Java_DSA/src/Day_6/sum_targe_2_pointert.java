package Day_6;

import java.util.Scanner;
import java.util.Arrays;

public class sum_targe_2_pointert {
    public static boolean sum_target(int[] arr,int target){
        boolean res=false;
        Arrays.sort(arr);
        int left=0;
        int right=arr.length-1;
        while(left<right){
            int sum=arr[left]+arr[right];
            if(sum==target){
                res=true;
                break;
            }
            else if(sum>target)
                right--;
            else
            left++;
        }
        return res;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the target : ");
        int target=scn.nextInt();
        boolean result=sum_target(arr,target);
        System.out.println(result);
    }
}
