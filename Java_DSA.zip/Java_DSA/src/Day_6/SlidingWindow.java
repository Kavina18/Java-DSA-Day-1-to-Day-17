package Day_6;

import java.util.Scanner;

public class SlidingWindow {
    public static int Max_k_Consecutive_Sum(int[] arr,int k){
        /*int max_sum=Integer.MIN_VALUE;
        int sum=0;*/
        if(k>arr.length){
            return -1;
        }
        /*for(int i=0;i<=arr.length-k;i++){
            for(int j=0;j<k;j++){
                sum+=arr[i+j];
            }
            max_sum=Math.max(max_sum,sum);
            sum=0;
        }
        return max_sum;*/
        int max_sum=0;
        for(int i=0;i<k;i++){
            max_sum+=arr[i];
        }
        int windowsum=max_sum;
        for(int i=k;i<arr.length;i++){
            windowsum+=arr[i]-arr[i-k];
            max_sum=Math.max(max_sum,windowsum);
        }
        return max_sum;
    }
    public static void main(String[] args) {
        Scanner scn=new Scanner(System.in);
        System.out.println("Enter the size:");
        int n=scn.nextInt();
        int[] arr=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++){
            arr[i]=scn.nextInt();
        }
        System.out.println("Enter the k consecutive : ");
        int k=scn.nextInt();
        int sum=Max_k_Consecutive_Sum(arr,k);
        System.out.println("Maximum sum of k consecutive elements in array : "+sum);
    }
}
